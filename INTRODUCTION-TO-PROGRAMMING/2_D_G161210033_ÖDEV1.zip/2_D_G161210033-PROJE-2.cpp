﻿#include<iostream>
using namespace std;

/****************************************************************************
**					        SAKARYA ÜNİVERSİTESİ
**			         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				         BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          PROGRAMLAMAYA GİRİŞİ DERSİ
**
**				ÖDEV NUMARASI: 1
**				ÖĞRENCİ ADI: BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
*****************************************************************************/




int main()
{
	int sayi1;
	int sayi2;

	cout << "Birinci sayi ikinci sayidan buyuk olacak sekilde iki sayi giriniz";
	cin >> sayi1 >> sayi2;

	for (int x = 1; x <= 20; x++) // x değeri 20 değerliklidir
	{
		if (x == 1)
		{
			cout << " 1:";

			for (int a = 1; a <= sayi2; ++a)// sayı2 değerine kadar boşluk yazdırıyor
			{
				cout << " ";

			}

			for (int a = sayi1 + 1; a <= 20; ++a)// sayı1 den 20 ye kadar yıldız yazdırır
			{
				cout << "*";
				

			}
			cout << endl;
		}
		else if (x == 2)
		{
			cout << " 0:";

			for (int a = 1; a <= sayi2; ++a)//sayı2 değerine kadar boşluk yazdır
			{
				cout << " ";
			}

			for (int a = sayi2; a <= sayi1; ++a)// sayı2 den sayı1 e kadar yıldız yazdırır 
			{
				cout << "*";
				
			}
			cout << endl;
		}
		else if (x == 3)
		{
			cout << "-1:";

			for (int a = 1; a < sayi2; ++a)//sayı2 değerine kadar yıldız bas
			{
				cout << "*";
				
			}
			cout << endl;
		}



		}

	system("pause");
	return 0;

	




}