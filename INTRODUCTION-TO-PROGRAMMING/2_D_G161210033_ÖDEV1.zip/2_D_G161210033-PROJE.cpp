﻿#include<iostream>
#include<iomanip>

using namespace std;
/****************************************************************************
**			          SAKARYA ÜNİVERSİTESİ
**			  BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				  BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				   PROGRAMLAMAYA GİRİŞİ DERSİ
**
**				ÖDEV NUMARASI: 1
**				ÖĞRENCİ ADI: BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
***************************************************************************/

int main()
{
	int satir;//satir değişkeni tanımladık.

	for (int satir = 0; satir <= 24; satir++)
	{
		// İlk ve son satırın tamamına asterix ekler.
		if (satir == 0 || satir == 24)
		{
			for (int m = 0; m <= 25; m++)//0 dan 25 e kadar yıldız ekliyor.
			{
				cout << "*";


			}

			cout << endl;

		}



		if (satir == 1) // 1. satıra "SAU BILGISAYAR" yazar.
		{

			cout << "*SAU BILGISAYAR" << setw(11) << "*";
			cout << endl;

		}




		if (satir == 2)//2. satıra baş ve son sütuna yıldız ekler.
		{
			cout << "*" << setw(25) << "*";
			cout << endl;
		}


		// 4. Satırdan itibaren Üçgen çizmeye başlar.
		if (satir == 3)
		{




			//Tek sayı değişkeni
			int n = 1;


			// 6 Satırlık üçgen çizilir.
			for (int i = 0; i <= 5; i++)
			{

				// İlk üçgen boşluklarını ekler.
				for (int j = 5; j >= i; j--)
				{

					// Kareyi çizmek için ilk sütuna asterix ekler.
					if (j == 5)
					{
						cout << "*";
					}
					else
					{
						cout << " ";
					}
				}

				// İlk üçgen Tek sayı ile asterix eklenir.
				for (int k = 0; k < n; k++)
				{
					cout << "*";
				}

				// İlk üçgen sonrası boşlukları ekler.
				for (int j = 5; j >= i; j--)
				{
					cout << " ";
				}

				// İkinci üçgen boşluklarını ekler.
				for (int j = 5; j >= i; j--)
				{
					cout << " ";
				}


				// İkinci üçgen Tek sayı ile asterix eklenir.
				for (int k = 0; k < n; k++)
				{
					cout << "*";


				}

				// İkinci üçgen sonrası boşluklarını ekler.
				for (int j = 5; j >= i; j--)
				{

					// Kareyi çizmek için son sütuna asterix ekler.
					if (j == i)
					{
						cout << "*";
					}
					else
					{
						cout << " ";
					}
				}

				cout << endl;

				n = n + 2;



			}
		}

		if (satir == 10)//10. satırın baş ve son sütununa yıldız ekler.
		{
			cout << "*" << setw(25) << "*";
			cout << endl;
		}


		if (satir == 11) // 11. satıra "SAU BILGISAYAR" yazar.
		{
			cout << "*MUHENDISLIGI BOLUMU" << setw(6) << "*";
			cout << endl;
		}

		if (satir == 12)//12. satırın baş ve son sütununa yıldız ekler.
		{
			cout << "*" << setw(25) << "*";
			cout << endl;
		}
		
		if (satir == 13)// 13. Satırdan itibaren Üçgen çizmeye başlar.
		{





			//Tek sayı değişkeni
			int n = 1;


			// 6 Satırlık üçgen çizilir
			for (int i = 0; i <= 5; i++)
			{

				// İlk üçgen boşluklarını ekler
				for (int j = 5; j >= i; j--)
				{

					// Kareyi çizmek için ilk sütuna asterix ekler
					if (j == 5)
					{
						cout << "*";
					}
					else
					{
						cout << " ";
					}
				}

				// İlk üçgen Tek sayı ile asterix eklenir.
				for (int k = 0; k < n; k++)
				{
					cout << "*";
				}

				// İlk üçgen sonrası boşlukları ekler
				for (int j = 5; j >= i; j--)
				{
					cout << " ";
				}

				// İkinci üçgen boşluklarını ekler
				for (int j = 5; j >= i; j--)
				{
					cout << " ";
				}


				// İkinci üçgen Tek sayı ile asterix eklenir.
				for (int k = 0; k < n; k++)
				{
					cout << "*";
				}

				// İkinci üçgen sonrası boşluklarını ekler
				for (int j = 5; j >= i; j--)
				{
					// Kareyi çizmek için son sütuna asterix ekler
					if (j == i)
					{
						cout << "*";
					}
					else
					{
						cout << " ";
					}
				}

				cout << endl;

				n = n + 2;




			}
		}

		if (satir == 19)//19. satırın baş ve son sütununa yıldız ekler.
		{
			cout << "*" << setw(25) << "*";
			cout << endl;
		}

	}







	system("pause");
	return 0;



}
