﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			     BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          PROGRAMLAMAYA GİRİŞ DERSİ
**
**				ÖDEV NUMARASI:4
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

#include<iostream>
#include<iomanip>
using namespace std;
#define satır 10 // Satır değerini 10 aldım.
#define sutun 10 // Sütun değerini 10 aldım.
int dizi[satır][sutun]; //10x10 matris tanımladım.

void olustur(int dizi[satır][sutun]) // Elamanları 1-100 arasında 10x10 matris oluşturan fonksiyon başlangıcı.
{
	srand((unsigned)time(0)); // Her defasında farklı eleman çağırır.
	
	for (int i = 0; i < satır; i++) // Değereleri satır'a kadar artırır.
	{
		for (int j = 0; j < sutun; j++) // Değereleri sütun'a kadar artırır.
		{
			dizi[i][j] = rand() % 100 + 1; // Randomla değer atar.
		}
	}

	for (int i = 0; i < satır; i++) // Değereleri satır'a kadar artırır.
	{
		for (int j = 0; j < sutun; j++) // Değereleri sütun'a kadar artırır.
		{
			cout << setw(5) << dizi[i][j]; // Matrisi yazdırır.
			
		}
		cout << endl;
	}

}// Elamanları 1 - 100 arasında 10x10 matris oluşturan fonksiyon sonu.

void sirala(int dizi[satır][sutun]) //Elemanları büyükten küçüğe sıralayan fonksiyon başlangıcı.
{
	for (int row = 0; row < 10; row++)  // Satırı 10' kadar artırır.
	{
		for (int column = 0; column < 10; column++)  // Sütunu  10'a kadar artırır.
		{ 
			for (int i = 0; i < 10; i++)  // Değereleri 10'a kadar artırır(Satır için).
			{

				for (int j = i; j < 10; j++)  // Değereleri 10'a kadar artırır(Sütun için).
				{

					// Hem satır hem de sütun içinde karşılaştırma yaparak büyükten küçüğe sıralar.
					if (dizi[row][i] < dizi[row][j]) 
					{
						int temp = dizi[row][i];
						dizi[row][i] = dizi[row][j];
						dizi[row][j] = temp;
					}

					if (dizi[i][column] < dizi[j][column]) 
					{
						int temp = dizi[i][column];
						dizi[i][column] = dizi[j][column];
						dizi[j][column] = temp;
					}
				}
			}
		}
	}
}//Elemanları büyükten küçüğe sıralayan fonksiyon sonu.
void matris_yaz(int dizi[satır][sutun])  //10x10 matrisi yazan fobksiyon başlagıcı.
{
	for (int i = 0; i<10; i++) // Satırı 10'a kadar artırır.
	{
		for (int j = 0; j<10; j++) // Sütunu 10'a kadar artırır.
		{ 
			cout << setw(5) << dizi[i][j]; // Matrisi yazdırır.
		}
		cout << endl;
	}
} //10x10 matrisi yazan fonksiyon sonu.
int main() // Main fonksiyonu başlangıcı.
{
	srand((unsigned)time(0)); // Her defasında farklı eleman çağırır.


	cout << "Toplam rastgele cagrim adedi=" << rand() % 100 + 1 << endl; //Toplam rastgele cagrim adedini ekrana yazdırır.
	cout << "Rastgele olusan ve elemanlari birbirinden farkli matris" << endl;

	olustur(dizi);// Olustur fonksiyonunu çağırır.



	cout << endl << endl << "Buyukten kucuge siralanmis matris" << endl;
	sirala(dizi); // sirala fonksiyonunu çağırır.
	matris_yaz(dizi); // matris_yaz fonksiyonunu çağırır.
	cout << endl;

	system("pause");
	return 0;
}// Main fonksiyonu sonu.







	


