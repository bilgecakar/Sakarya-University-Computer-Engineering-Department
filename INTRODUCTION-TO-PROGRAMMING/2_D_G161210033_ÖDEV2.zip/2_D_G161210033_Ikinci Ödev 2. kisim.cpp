﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			     BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          PROGRAMLAMAYA GİRİŞİ DERSİ
**
**				ÖDEV NUMARASI:2
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

#include<iostream>
#include<array>
#include<iomanip>
#include<conio.h>

using namespace std;

int main()//main fonksiyou program icrasını başlatır.
{
	
	int karakter; //Karakte değeri tanımlıyoruz.
	int k=0; //k değeri tanımlıyoruz. 

	

	if (k == 0) // k=0 olduğunda birinci satıra ok basar ve dizi oluşturur.
	{
		cout << "--->";
	
       int dizi[10]; //10 elemanlı dizi tanımladık.


		for (int i = 0; i < 10; i++) //Diziyi rastgele atama yapar.
		{
			

			dizi[i] = rand() % 10; 
			cout << dizi[i] << endl;

		

			for (int k = 1; k < 5; k++) //Okun aşağısınıa boşluk ekler.
			{
				cout << " ";

			}

		}
		
	
	}
	

	cout << endl;
   

	// Kullanıcından karakter girmesini ister.
	cout << "(a ve A tusu asagi goturur.)" << endl;
	cout << "(d ve D tusu yukari goturur.)" << endl;
	cout << "(c ve C tusu programdan cikar.)" << endl;
	cout << "Bir karakter giriniz:";
	cin >> karakter;

	

		



	system("pause");
	return 0;


} // main fonksiyonu sonu