﻿/****************************************************************************
**					          SAKARYA ÜNİVERSİTESİ
**			         BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				          BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				            PROGRAMLAMAYA GİRİŞİ DERSİ
**
**				ÖDEV NUMARASI:2
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

int main() // main fonksiyonu program icrasını başlatır.
{
	// İstenen değerleri tanımlıyoruz.
	int vizenotu;
	int birinciödev;
	int ikinciödev;
	int birincikisasinav;
	int ikincikisasinav;
	int finalnotu;
	int a, b, c, d; // Ek olarak yüzdelik değerleri tanımlıyoruz.
	
	
	cout << "Vize notunu giriniz:";     //Vize notunu girer.
	cin >> vizenotu;

	cout << "Birinci odev notunu giriniz:";    //Birinci ödev notunu girer.
	cin >> birinciödev;

	cout << "Ikinci odev notunu giriniz:";    //İkinci ödev notunu  girer.
	cin >> ikinciödev;

	cout << "Birinci kisa sinav notunu giriniz:";   //Birinci kısa sınav notunu girer.
	cin >> birincikisasinav;

	cout << "Ikinci kisa sinav notunu giriniz:";    //İkinci kısa sınav notunu girer.
	cin >> ikincikisasinav;

	cout << "Final sinavı notunu giriniz:";     // Final sınavı notunu girer.
	cin >> finalnotu;

	cout << "Vizenin yil icine etkisi yuzde kac olacaktir:";   // Vizenin yüzdelik etkisini girer.
	cin >> a;

	cout << "Odevlerin yil icine etkisi yuzde kac olacaktir:";    //Ödevlerin yüzdelik etkisini girer.
	cin >> b;

	cout << "Kisa sinavlarin  yil icine etkisi yuzde kac olacaktir:";    //Kısa sınavların yüzdelik etkisini girer.
	cin >> c;


	int kisasinavortalamasi; // Kısa sınavların ortalamasını hesaplar.

	kisasinavortalamasi = (birincikisasinav + ikincikisasinav) / 2;


	int ödevortalamasi;  //Ödevlerin ortalamasını hesaplar.

	ödevortalamasi = (birinciödev + ikinciödev) / 2;
	
	int yilicipuani;  // Vize , kısa sınav ve ödevlerin yüzdelik dilimlerinin toplamı yıl içi puanı olmaktadır.

	yilicipuani = vizenotu % a + kisasinavortalamasi % b + ödevortalamasi % c;

	cout << "Yil ici puaninin  etkisi yuzde kac olacaktir:  "; // Yıl içi puanının yüzdelik etkisini girer.
	cin >> d;

	int yilsonunotu;  // Yıl içi puanı ve final notunun yüzdelik dilimlerinin toplamı yıl sonu puanını vermektedir.

	yilsonunotu = yilicipuani % d + finalnotu % (100 - d);

	if (yilsonunotu >= 90 && yilsonunotu <= 100)  //Yıl sonu puanı 90-100 arasında ise AA alır.
	{
		cout << "Yil sonu notu:" <<  yilsonunotu <<setw(5) << "AA" << endl;
	
	}

	else if (yilsonunotu >= 85 && yilsonunotu <= 89)  //Yıl sonu puanı 85-89 arasında ise BA alır.
	{
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "BA" << endl;

	}

	else if (yilsonunotu >= 80 && yilsonunotu <= 84)  //Yıl sonu puanı 80-84 arasında ise BB alır.
	{
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "BB" << endl;

	}

	else if (yilsonunotu >= 75  && yilsonunotu <= 79)  //Yıl sonu puanı 75-79 arasında ise CB alır.
	{
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "CB" << endl;

	}


	else if (yilsonunotu >= 65 && yilsonunotu <= 74) //Yıl sonu puanı 65-74 arasında ise CC alır.
	{
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "CC" << endl;

	}

	else if (yilsonunotu >= 58 && yilsonunotu <= 64)  //Yıl sonu puanı 58-64 arasında ise DC alır.
	{ 
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "DC" << endl;

	}

	else if (yilsonunotu >= 50 && yilsonunotu <= 57)  //Yıl sonu puanı 50-57 arasında ise DD alır.
	{
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "DD" << endl;

	}

	else if (yilsonunotu >= 0 && yilsonunotu <= 49)  //Yıl sonu puanı 0-49 arasında ise FF alır.
	{
		cout << "Yil sonu notu:" << yilsonunotu << setw(5) << "FF" << endl;

	}


	system("pause");

		return 0; 



} //main fonksiyonu sonu.