﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			     BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          PROGRAMLAMAYA GİRİŞİ DERSİ
**
**				ÖDEV NUMARASI:2
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

#include <iostream>
#include <math.h> 
#include<iomanip>
using namespace std;

int main()  //main fonksiyou program icrasını başlatır.
{

	float a, b, c; //Kat sayıları tanımlıyoruz.
	float x1, x2; //Kökleri tanımlıyoruz.
	float delta; //Delta değerini tanımlıyoruz.

	cout << "a, b ve c katsayilarini giriniz: "; //Kullanıcıdan üç değer girmesini ister.
	cin >> a >> b >> c;

	delta = b*b - 4*a*c; // Dalta değerinin matematiksel dökümüdür.

	if (delta < 0) // Delta sıfırdan küçükse  ekrana kökler karmaşıktır yazısını yazdırır.
	{
		cout << "Kokler karmasik." << endl;

	}

	else if (delta == 0) // Delta sıfıra eşitse ekrana köklerin sonucunu ve çakışan iki kök  vardır yazısını yazdırır.
	{
		x1 = -b / (2 * a); // Deltanın sfıra eşit olması durumunda  köklerin matematiksel dökümüdür.
		x2 = -b / (2 * a);
		cout << "Cakisan iki kok vardir:" << setw(3) << x1 <<setw(3)<< x2 << endl;
	}

	else if (delta > 0) // Delta sıfırdan büyükse kökleri hesaplar ve ekrana  iki gerçel kök vardır yazısını yazdırır.
	{
		x1 = (-b + sqrt(delta)) / 2 * a;//  Deltanın sıfırdan büyük olması durumunda köklerin matematiksel dökümüdür.
		x2 = (-b - sqrt(delta)) / 2 * a;

		cout << x1<< setw(3) << " ve " << setw(3) << x2 << setw(5) << " noktalarinda iki gercel kok vardir." << endl;

	}


	system("pause");
	return 0 ;
}// main fonksiyonu sonu.