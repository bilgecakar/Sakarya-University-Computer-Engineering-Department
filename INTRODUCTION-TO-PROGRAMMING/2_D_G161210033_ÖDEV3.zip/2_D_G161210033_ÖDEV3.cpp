﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			     BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          PROGRAMLAMAYA GİRİŞ DERSİ
**
**				ÖDEV NUMARASI:3
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

#include<iostream>
#include<string>
#include<locale.h>
#include<conio.h>
#include<iomanip>
#define SIZE 1000 //Dizi elemanı değişmeyecek şekilde eklenir.
using namespace std;

struct  CUMLE // struct CUMLE tanımladım.
{
	char cumle[SIZE]; // cumle karakter dizisi oluşturdum.


};


int noktalama_isareti(const char *cumle); // Noktalama işareti türünü bulan fonksiyon tanımladım.

int noktalam_isareti_sayısı(const char  * cumle); // Noktalama işareti sayısını bulan fonksiyon tanımladım.

int c_harf_ve_kelime_sayisi(const char *cumle); // Cümledeki harf ve kelime sayısını  bulan fonksiyon tanımladım.

int palindrom(const char *p); // Cümlenin palindrom olup olmadğını bulan fonksiyon tanımladım.

int kelimenin_harf_ve_sesli_sesiz_harf_sayisi(char *cumle); // Cümledeki kelimelerin harf saysını ve sesli, sesiz harf sayısını bulan fonksiyon tanımladım.

int main() // main fonksiyonu program icrasını başlatır.
{
	setlocale(LC_ALL, "Turkish");

	struct CUMLE CLM; //structı çağırdım.
	CLM.cumle;


	cout << "Yazi Giriniz:"; // Bir cümle girilmesini istedim.
	gets_s(CLM.cumle);

	// Fonksiyonları çağırdım ve parametre değeri olarak CLM.cumle yani girilen cümleyi olarak atadım.
    c_harf_ve_kelime_sayisi(CLM.cumle);

	noktalama_isareti(CLM.cumle);

	noktalam_isareti_sayısı(CLM.cumle);

	

	if (palindrom(CLM.cumle))
	{
		cout << "Evet palindromn." << endl; //Palindrom ise "Evet palindromn." yazısını ekrana verecek.
	}
	else
	{
		cout << "Hayir palindrom degil." << endl; //Palindrom değilse "Hayir palindrom degil."  yazısını ekrana verecek.
	}


	kelimenin_harf_ve_sesli_sesiz_harf_sayisi(CLM.cumle);

	system("pause");
	return 0;
}//main fonksiyonu sonu



int noktalama_isareti(const char *cumle)//Noktalama işareti türünü bulan fonksiyonun başlangıcı.
{
	//Noktalama işaretlerini tanımladım.
	char a = '.';
	char b = ',';
	char c = '!';
	char d = ';';
	char e = ':';
	char f = '?';
	char g = '-';


	if (strchr(cumle, a) != NULL) // Nokta işareti varsa ekrana "Nokta isareti var." yazdır.
	{
		cout << "Nokta isareti var." << endl;

	}
	if (strchr(cumle, b) != NULL) // Virgül işareti varsa ekrana "Virgul isareti var." yazdır.
	{
		cout << "Virgul isareti var." << endl;
	}
	if (strchr(cumle, c) != NULL) // Ünlem işareti varsa ekrana "Unlem isareti var." yazdır.
	{
		cout << "Unlem isareti var." << endl;
	}
	if (strchr(cumle, d) != NULL) // Noktalı virgül varsa ekrana "Noktali virgul  var." yazdır.
	{
		cout << "Noktali virgul  var." << endl;
	}
	if (strchr(cumle, e) != NULL) // İki nokta işareti varsa ekrana "Iki nokta isareti var." yazdır.
	{
		cout << "Iki nokta isareti var." << endl;
	}
	if (strchr(cumle, f) != NULL) // Soru işareti varsa ekrana  "Soru isareti var." yazdır.
	{
		cout << "Soru isareti var." << endl;
	}
	if (strchr(cumle, g) != NULL) // Kısa çizgi varsa ekrana "Kisa cizgi var." yazdır.
	{
		cout << "Kisa cizgi var." << endl;
	}


	return 0;
}//Noktalama işareti türünü bulan fonksiyonun sonu.

int noktalam_isareti_sayısı(const char  * cumle) // Noktalama işareti sayısını bulan fonksiyonunun başlangıcı.
{

	// işaret, uzunluk, i, noktalama_isareti değerlerini tanımlıyoruz.
	char isaret;
	int uzunluk, i;
	int noktalama_isareti = 0;

	uzunluk = strlen(cumle); // Uzunluk değeri cümlenin uzunluğudur.

	for (i = 0; i < uzunluk; i++) //i değerini uzunluk değeri kadar arttır.
	{
		isaret = cumle[i];//İşaret cümelnin içinde.
		if (isaret == '.' || isaret == ',' || isaret == '!' || isaret == ';' || isaret == ':' || isaret == '?' || isaret == '-')// İşaretleri tanımlar ve noktalama işarati varsa sayacı artırır.
		{
			noktalama_isareti += 1;
		}

	}


	cout << "Noktalama isareti sayisi:" << noktalama_isareti << endl; //Noktalama işaretinin saysını ekrana yazar.

	return 0;




} // Noktalama işareti sayısını bulan fonksiyonun sonu.


int c_harf_ve_kelime_sayisi(const char *cumle) // Cümlenin harf ve kelime sayısını bulan fonksiyonun başlangıcı.
{
	// Fonksiyon içinde kullandığım değerleri tanımlıyorum.
	int ks = 0;
	int bos_adet = 0;
	char bosluk[] = { " " };
	char isaret;
	int uzunluk, i;
	int noktalama_isareti = 0;


	for (int i = 0; i < strlen(cumle); i++)//i değerini uzunluk değeri kadar arttır.
	{

		for (int j = 0; j < 1; j++)

		{

			if (cumle[i] == bosluk[j])//Harfler boşluğa geldiğinde sayaçları arttırır.
			{
				ks++;//Kelime sayısı için.
				bos_adet++;//Boşluk sayısı için.
				break;

			}

		}

	}


	uzunluk = strlen(cumle); // Uzunluk değeri cümlenin uzunluğudur.

	for (i = 0; i < uzunluk; i++)//i değerini uzunluk değeri kadar arttır.
	{
		isaret = cumle[i];//İşaret cümlenin içinde yer alır.
		if (isaret == '.' || isaret == ',' || isaret == '!' || isaret == ';' || isaret == ':' || isaret == '?' || isaret == '-')// İşaretleri tanımlar ve noktalama işarati varsa sayscı artırır.
		{
			noktalama_isareti += 1;
		}

	}



	cout << "Cümlenin harf sayisi:" << strlen(cumle) - (bos_adet + noktalama_isareti) << endl; //Cümlenin harf sayısını ekrana yazdırır.
	cout << "Cümlenin kelime sayisi:" << ks + 1 << endl; //Cümlenin kelime saysını ekrana yazdırır.

	return 0;

}// Cümlenin harf ve kelime sayısını bulan fonksiyonun sonu.

int palindrom(const char *p) // Palindrom fonksiyonu başlangıcı.
{
	//Fonksiyonda kullandığım değerleri tanımladım.
	char cumle[SIZE];
	int k;
	int index = 0;

	for (k = 0; p[k] != ' '; ++k)//p[k] değeri boşluğa eşit olmayacak koşuluyla k değerini arttırır. 

		if (isalpha(p[k]))
			cumle[index++] = toupper(p[k]);

	for (k = 0; k < index / 2; ++k)//İndex'in yarısı kadar artırır.

		if (cumle[k] != cumle[index - 1 - k])
			return 0;

	return 1;
}  // Palindrom fonksiyonu sonu.

int kelimenin_harf_ve_sesli_sesiz_harf_sayisi(char *cumle) //Kelimenin harf sayIsını  ve sesli, sessiz harf sayısını bulan  fomksiyonun başlangıcı.

{   //Fonksiyonda kullandığım değerleri tanımladım.
	char* birkelime;
    char harf;
	int uzunluk, i, j;
	int sayac_sesli = 0, sayac_sessiz = 0;
	char isaret;
	int noktalama_isareti = 0;
	

	birkelime = strtok_s(cumle, " ", &cumle);  //Cümle dizisini dizgelere ayrırır.
	while (birkelime != NULL)
	{

		for (i = 0; i < strlen(birkelime); i++) //Kelimelerin sesli ve sessiz harf sayısını bulur.
		{

			

			harf = birkelime[i]; //Harf kelimenin içinde yer alır.
			if (harf == 'a' || harf == 'A' || harf == 'e' || harf == 'E' || harf == 'i' || harf == 'I' || harf == 'o' || harf == 'O' || harf == 'u' || harf == 'U') // Sesli harfleri tanımlar ve sesli versa saycı arttırır.
			{
				sayac_sesli += 1;
			}
			else if (harf != ' ') // Sessiz harf vara sayacı arttırır.
			{
				sayac_sessiz += 1;
			}
		}

		for (j = 0; j <strlen(birkelime); j++) //i değerini uzunluk değeri kadar arttır.
		{


			isaret = birkelime[j];//İşaret kelimenin içinde yer alır.
			if (isaret == '.' || isaret == ',' || isaret == '!' || isaret == ';' || isaret == ':' || isaret == '?' || isaret == '-') // İşaretleri tanımlar ve noktalama işarati varsa sayscı arttırır.
			{
				noktalama_isareti += 1;
			}

		}

		
		cout << birkelime << " " << "kelimesinin sesli harf sayisi:" << sayac_sesli << endl << birkelime << " " << "kelimesinin sessiz harf sayisi:" << sayac_sessiz << endl; // Kelimelerin sesli ve sessiz harf sayısını ekrana yazdırır.
		cout << birkelime << " " << "kelimesinin harf sayisi:" << strlen(birkelime)-noktalama_isareti << endl;//Kelimenin saysısnı ekrana yazdırır.
		birkelime = strtok_s(NULL, " ", &cumle);
	}

	
    system("pause");
	return 0;
} // Kelimenin harf sayIsını  ve sesli, sessiz harf sayısını bulan  fomksiyonun başlangıcı.
