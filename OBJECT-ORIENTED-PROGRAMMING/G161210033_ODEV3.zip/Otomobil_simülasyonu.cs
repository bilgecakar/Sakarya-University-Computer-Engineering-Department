﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			     BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				         NESNEYE DAYALI PROGRAMLAMA 
**                              3. ÖDEVİ
**				ÖDEV NO:3
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Araba
{
    enum Direksiyon_yonu
    {
        Saga_donuk,
        Sola_donuk,
        Duz
    }

    enum Farlar
    {
        Kisa_farlar,
        Uzun_farlar
    }

    enum Sinyal_lambalari
    {
        Sag_sinyal,
        Sol_sinyal
    }

    enum Motor_turu
    {
        Benzinli,
        Dizel
    }

    interface ICalistirma
    {
        void Direksiyon(Direksiyon_yonu  direksiyon);
        void Tekerlek();
        double Hiz_gostergesi { get; set; }
        Direksiyon_yonu direksiyon { get; set; }
        Sinyal_lambalari sinyal { get; set; }
        Farlar far { get; set; }
        void Sinyal_Kumanda_Kolu(Sinyal_lambalari sinyal);
        void Far_Kumanda_Kolu(Farlar far);

    }
    interface ISurme
    {
        Motor_turu motor { get; set; }
        void Motor(Motor_turu  motor);
        void Kontak_Anahtari();
        void Gaz_Pedali_ve_Fren_Pedali();
        
        
    }
    class Elektronik_Beyin : ISurme, ICalistirma
    {
       
        public Farlar far { get; set; }
        public Direksiyon_yonu direksiyon { get; set; }
        public Sinyal_lambalari sinyal { get; set; }
        public Motor_turu motor { get; set; }

        public void Direksiyon(Direksiyon_yonu direksiyon)
        {
            this.direksiyon = direksiyon;    
        }

        public void Far_Kumanda_Kolu(Farlar far)
        {
            this.far = far;
        }

        public double hiz;

        public void Gaz_Pedali_ve_Fren_Pedali()
        {
            
            bool Gaz_Basma = false;
            bool Fren_Basma = false;
            if (Gaz_Basma==true)
            {
                if(motor == Motor_turu.Benzinli)
                {

                        hiz += 10;

                        if (hiz >= 220)
                        {
                            hiz = 220;
                        }

                        if (Fren_Basma == true)
                        {

                            hiz -= 10;

                            if (hiz <= 0)
                            {
                                hiz = 0;

                            }

                        }
                    
                }
                else if (motor == Motor_turu.Dizel)
                {
                   
                        hiz += 8;

                        if (hiz == 216)
                        {
                            hiz = 220;
                        }

                        if (Fren_Basma == true)
                        {

                            hiz -= 10;

                            if (hiz <= 0)
                            {
                                hiz = 0;

                            }

                        }

                }
            }
        }

        public double Hiz_gostergesi
        {

            get { return Hiz_gostergesi; }

            set
            {
                if (value == hiz)
                {
                    Hiz_gostergesi = hiz;

                }
            }

        }

        public void Kontak_Anahtari()
        {
            bool Kontak_Anahtari = true;
            
            if(Kontak_Anahtari==false)
            {
                 this.far = far;
                 this.sinyal = sinyal;
            }
        }

        public void Motor(Motor_turu motor)
        {
            this.motor = motor;
        }

        public void Sinyal_Kumanda_Kolu(Sinyal_lambalari sinyal)
        {
            this.sinyal = sinyal;
        }

        public void Tekerlek()
        {
            int donus_acisi = 0;
            
            if (donus_acisi<=45)
            {
                donus_acisi += 5;

            }
            
        }
    }
    class Otomobil : Elektronik_Beyin
    {


    }

    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
