﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paint
{
    class Daire:Tum_Sekiller
    {
        public int yaricap;

        public void daire()
        {
            yaricap = 0;
        }

        public override void Bitis(int bx, int by)
        {
            yaricap = bx - X;

        }

        public override void Ciz(Graphics CizimAlani, Color renk)
        {

            SolidBrush firca = new SolidBrush(renk);
            Rectangle circle = new Rectangle(X, Y, yaricap, yaricap);
            CizimAlani.FillEllipse(firca, circle);
            firca.Dispose();

        }
    }
}
