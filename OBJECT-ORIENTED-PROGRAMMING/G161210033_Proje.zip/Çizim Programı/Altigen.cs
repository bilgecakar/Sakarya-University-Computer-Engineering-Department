﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paint
{
    class Altigen:Tum_Sekiller
    {
        int genislik;
        int yükseklik;

        public override void Bitis(int bx, int by)
        {
            genislik = bx - X;
            yükseklik = by - Y;
        }

        public override void Ciz(Graphics CizimAlani, Color renk)
        {
            SolidBrush firca = new SolidBrush(renk);
            int X_Uzunluk = Math.Abs(genislik);
            var array = new PointF[6];
            for (int i = 0; i < 6; i++)
            {
                array[i] = new PointF(
                  X + X_Uzunluk * (float)Math.Cos(i * 60 * Math.PI / 180f),
                  Y + X_Uzunluk * (float)Math.Sin(i * 60 * Math.PI / 180f));
            }
            CizimAlani.FillPolygon(firca, array);
            firca.Dispose();
         
        }
    }
}
