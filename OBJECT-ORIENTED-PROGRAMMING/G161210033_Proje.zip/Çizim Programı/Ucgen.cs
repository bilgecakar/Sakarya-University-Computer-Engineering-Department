﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paint
{
    class Ucgen:Tum_Sekiller
    {
        int genislik;
        int yükseklik;

        public override void Bitis(int bx, int by)
        {
            genislik = bx - X;
            yükseklik = by - Y;
        }

        public override void Ciz(Graphics CizimAlani, Color renk)
        {
            SolidBrush firca = new SolidBrush(renk);
            double basX = Math.Min(X, genislik);
            double basY = Math.Min(Y, yükseklik);
            double datX, datY;
            Point dat1 = new Point(X, Y);
            datY = Convert.ToDouble(basY) - (Convert.ToDouble(yükseklik) - Convert.ToDouble(basX) * Math.Pow(0.5, 3)) / 2;
            datX = Convert.ToDouble(basX) + (Convert.ToDouble(genislik) - Convert.ToDouble(basX)) / 2;
            Point dat2 = new Point(genislik, Y);
            Point dat3 = new Point(Convert.ToInt32(datX), Convert.ToInt32(datY));
            PointF[] p = { dat1, dat2, dat3 };
            CizimAlani.FillPolygon(firca, p);
            firca.Dispose();
           

        }
    }
}
