﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			     BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				          NESNEYE DAYALI PROGRAMLAMA
**                              PROJE ÖDEVİ
**				
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Paint
{
    public partial class Form1 : Form
    {
        public int x = 0;
        public int y = 0;
        int Max_Kare_Sayisi = 100;
        int sekil_Sayisi = 0;
        Tum_Sekiller[] sekiller;
        Kare karem = new Kare();
        Daire dairem = new Daire();
        Tum_Sekiller sk_secimi = null;
        bool tutma = false;
        bool kare_cizme = false;
        bool daire_cizme = false;
        bool ucgen_cizme = false;
        bool altigen_cizme = false;
        Color Brush = Color.Black;
        Graphics g;

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            sekiller = new Tum_Sekiller[Max_Kare_Sayisi];
            karem.genislik = 100;
           

        }

        private void Panel_MouseDown(object sender, MouseEventArgs e)
        {
            

            if (kare_cizme)
            {
                sk_secimi = new Kare();
            }
            if (daire_cizme)
            {
                sk_secimi = new Daire();
            }
            if (ucgen_cizme)
            {
                sk_secimi = new Ucgen();
            }
            if (altigen_cizme)
            {
                sk_secimi = new Altigen();
            }

            tutma = true;
            sk_secimi.X = e.X;
            sk_secimi.Y = e.Y;
            this.Invalidate();

        }

        private void Panel_MouseMove(object sender, MouseEventArgs e)
        {
           
            if (tutma)
            {
                sk_secimi.Bitis(e.X, e.Y);
                this.Invalidate();
            }

        }

        private void Panel_MouseUp(object sender, MouseEventArgs e)
        {
            tutma = false;
            if (sekil_Sayisi != Max_Kare_Sayisi)
            sekiller[sekil_Sayisi] = sk_secimi;
            sekil_Sayisi++;
            Invalidate();
        }

        private void Panel_Paint(object sender, PaintEventArgs e)
        {

             g = panel1.CreateGraphics();

            if (sk_secimi != null)
            {
                sk_secimi.Ciz(g, Brush);
                for (int i = 0; i < sekil_Sayisi; i++)
                {
                    sekiller[i].Ciz(g, Brush);

                }

            }

        }

        private void Kaydet_Click(object sender, EventArgs e)
        {
            Bitmap bmp = new Bitmap(this.panel1.Width, this.panel1.Height);
            this.panel1.DrawToBitmap(bmp, new Rectangle(0, 0, this.panel1.Width, this.panel1.Height));
            bmp.Save("panel.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
        }

        private void Dosya_Cagırma_Click(object sender, EventArgs e)
        {
            g = this.panel1.CreateGraphics();
            OpenFileDialog dosya = new OpenFileDialog();

            Stream stm;
            String dosya_adi;
            dosya.Filter = "All files (*.*)|*.*|All files (*.*)|*.*";
            dosya.FilterIndex = 2;

            if (dosya.ShowDialog() == DialogResult.OK)
            {

                if ((stm = dosya.OpenFile()) != null)
                {
                    dosya_adi = dosya.FileName;
                    stm.Close();
                    Point pt1 = new Point(0, 0);
                    g.DrawImage(Image.FromFile(dosya_adi), pt1);

                }

            }

        }

        private void Kare_Click(object sender, EventArgs e)
        {
            kare_cizme = true;
            daire_cizme = false;
            ucgen_cizme = false;
            altigen_cizme = false;
        }

        private void Daire_Click(object sender, EventArgs e)
        {
            kare_cizme = false;
            daire_cizme = true;
            ucgen_cizme = false;
            altigen_cizme = false;
        }

        private void Ucgen_Click(object sender, EventArgs e)
        {
            kare_cizme = false;
            daire_cizme = false;
            ucgen_cizme = true;
            altigen_cizme = false;
        }

        private void Altigen_Click(object sender, EventArgs e)
        {
            kare_cizme = false;
            daire_cizme = false;
            ucgen_cizme = false;
            altigen_cizme = true;
        }
        private void Secme_Click(object sender, EventArgs e)
        {
            kare_cizme = false;
            daire_cizme = false;
            ucgen_cizme = false;
            altigen_cizme = false;
        }

        private void Kirmizi_Click(object sender, EventArgs e)
        {
            if (!tutma)
            {
                Brush = Kirmizi.BackColor;
                panel1.Invalidate();
            }
        }

        private void Mavi_Click(object sender, EventArgs e)
        {
            if (!tutma)
            {
                Brush = Mavi.BackColor;
                panel1.Invalidate();
            }
        }

        private void Turuncu_Click(object sender, EventArgs e)
        {
            Brush = Turuncu.BackColor;
            panel1.Invalidate();
        }

        private void Yesil_Click(object sender, EventArgs e)
        {
            Brush = Yesil.BackColor;
            panel1.Invalidate();
        }

        private void Siyah_Click(object sender, EventArgs e)
        {
            Brush = Siyah.BackColor;
            panel1.Invalidate();
        }

        private void Mor_Click(object sender, EventArgs e)
        {
            Brush = Mor.BackColor;
            panel1.Invalidate();
        }

        private void Beyaz_Click(object sender, EventArgs e)
        {
            Brush = Beyaz.BackColor;
            panel1.Invalidate();
        }

        private void Pembe_Click(object sender, EventArgs e)
        {
            Brush = Pembe.BackColor;
            panel1.Invalidate();
        }

        private void Gri_Click(object sender, EventArgs e)
        {
            Brush = Gri.BackColor;
            panel1.Invalidate();
        }

      
    }
}
