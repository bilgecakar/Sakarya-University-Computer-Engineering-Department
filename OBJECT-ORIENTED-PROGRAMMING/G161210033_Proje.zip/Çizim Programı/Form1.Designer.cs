﻿namespace Paint
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Altigen = new System.Windows.Forms.Button();
            this.Daire = new System.Windows.Forms.Button();
            this.Ucgen = new System.Windows.Forms.Button();
            this.Kare = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Gri = new System.Windows.Forms.PictureBox();
            this.Pembe = new System.Windows.Forms.PictureBox();
            this.Beyaz = new System.Windows.Forms.PictureBox();
            this.Mor = new System.Windows.Forms.PictureBox();
            this.Siyah = new System.Windows.Forms.PictureBox();
            this.Yesil = new System.Windows.Forms.PictureBox();
            this.Turuncu = new System.Windows.Forms.PictureBox();
            this.Mavi = new System.Windows.Forms.PictureBox();
            this.Kirmizi = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Silme = new System.Windows.Forms.Button();
            this.Secme = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Dosya_Cagırma = new System.Windows.Forms.Button();
            this.Kaydet = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gri)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pembe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Beyaz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Siyah)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yesil)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Turuncu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mavi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kirmizi)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Location = new System.Drawing.Point(0, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(779, 732);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.Panel_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Panel_MouseUp);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.Altigen);
            this.panel2.Controls.Add(this.Daire);
            this.panel2.Controls.Add(this.Ucgen);
            this.panel2.Controls.Add(this.Kare);
            this.panel2.Location = new System.Drawing.Point(785, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(240, 173);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Şekil Seçimi";
            // 
            // Altigen
            // 
            this.Altigen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Altigen.BackgroundImage")));
            this.Altigen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Altigen.FlatAppearance.BorderSize = 0;
            this.Altigen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Altigen.Location = new System.Drawing.Point(137, 110);
            this.Altigen.Name = "Altigen";
            this.Altigen.Size = new System.Drawing.Size(52, 45);
            this.Altigen.TabIndex = 3;
            this.Altigen.UseVisualStyleBackColor = true;
            this.Altigen.Click += new System.EventHandler(this.Altigen_Click);
            // 
            // Daire
            // 
            this.Daire.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Daire.BackgroundImage")));
            this.Daire.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Daire.FlatAppearance.BorderSize = 0;
            this.Daire.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Daire.Location = new System.Drawing.Point(137, 36);
            this.Daire.Name = "Daire";
            this.Daire.Size = new System.Drawing.Size(52, 45);
            this.Daire.TabIndex = 2;
            this.Daire.UseVisualStyleBackColor = true;
            this.Daire.Click += new System.EventHandler(this.Daire_Click);
            // 
            // Ucgen
            // 
            this.Ucgen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Ucgen.BackgroundImage")));
            this.Ucgen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Ucgen.FlatAppearance.BorderSize = 0;
            this.Ucgen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ucgen.Location = new System.Drawing.Point(45, 110);
            this.Ucgen.Name = "Ucgen";
            this.Ucgen.Size = new System.Drawing.Size(52, 45);
            this.Ucgen.TabIndex = 1;
            this.Ucgen.UseVisualStyleBackColor = true;
            this.Ucgen.Click += new System.EventHandler(this.Ucgen_Click);
            // 
            // Kare
            // 
            this.Kare.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Kare.BackgroundImage")));
            this.Kare.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Kare.FlatAppearance.BorderSize = 0;
            this.Kare.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Kare.Location = new System.Drawing.Point(45, 36);
            this.Kare.Name = "Kare";
            this.Kare.Size = new System.Drawing.Size(52, 45);
            this.Kare.TabIndex = 0;
            this.Kare.UseVisualStyleBackColor = true;
            this.Kare.Click += new System.EventHandler(this.Kare_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel3.Controls.Add(this.Gri);
            this.panel3.Controls.Add(this.Pembe);
            this.panel3.Controls.Add(this.Beyaz);
            this.panel3.Controls.Add(this.Mor);
            this.panel3.Controls.Add(this.Siyah);
            this.panel3.Controls.Add(this.Yesil);
            this.panel3.Controls.Add(this.Turuncu);
            this.panel3.Controls.Add(this.Mavi);
            this.panel3.Controls.Add(this.Kirmizi);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(785, 172);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(240, 181);
            this.panel3.TabIndex = 2;
            // 
            // Gri
            // 
            this.Gri.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Gri.Location = new System.Drawing.Point(189, 138);
            this.Gri.Name = "Gri";
            this.Gri.Size = new System.Drawing.Size(23, 23);
            this.Gri.TabIndex = 14;
            this.Gri.TabStop = false;
            this.Gri.Click += new System.EventHandler(this.Gri_Click);
            // 
            // Pembe
            // 
            this.Pembe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.Pembe.Location = new System.Drawing.Point(110, 138);
            this.Pembe.Name = "Pembe";
            this.Pembe.Size = new System.Drawing.Size(23, 23);
            this.Pembe.TabIndex = 13;
            this.Pembe.TabStop = false;
            this.Pembe.Click += new System.EventHandler(this.Pembe_Click);
            // 
            // Beyaz
            // 
            this.Beyaz.BackColor = System.Drawing.Color.White;
            this.Beyaz.Location = new System.Drawing.Point(29, 138);
            this.Beyaz.Name = "Beyaz";
            this.Beyaz.Size = new System.Drawing.Size(23, 23);
            this.Beyaz.TabIndex = 12;
            this.Beyaz.TabStop = false;
            this.Beyaz.Click += new System.EventHandler(this.Beyaz_Click);
            // 
            // Mor
            // 
            this.Mor.BackColor = System.Drawing.Color.Purple;
            this.Mor.Location = new System.Drawing.Point(189, 92);
            this.Mor.Name = "Mor";
            this.Mor.Size = new System.Drawing.Size(23, 23);
            this.Mor.TabIndex = 11;
            this.Mor.TabStop = false;
            this.Mor.Click += new System.EventHandler(this.Mor_Click);
            // 
            // Siyah
            // 
            this.Siyah.BackColor = System.Drawing.Color.Black;
            this.Siyah.Location = new System.Drawing.Point(110, 92);
            this.Siyah.Name = "Siyah";
            this.Siyah.Size = new System.Drawing.Size(23, 23);
            this.Siyah.TabIndex = 10;
            this.Siyah.TabStop = false;
            this.Siyah.Click += new System.EventHandler(this.Siyah_Click);
            // 
            // Yesil
            // 
            this.Yesil.BackColor = System.Drawing.Color.Lime;
            this.Yesil.Location = new System.Drawing.Point(29, 92);
            this.Yesil.Name = "Yesil";
            this.Yesil.Size = new System.Drawing.Size(23, 23);
            this.Yesil.TabIndex = 9;
            this.Yesil.TabStop = false;
            this.Yesil.Click += new System.EventHandler(this.Yesil_Click);
            // 
            // Turuncu
            // 
            this.Turuncu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Turuncu.Location = new System.Drawing.Point(189, 45);
            this.Turuncu.Name = "Turuncu";
            this.Turuncu.Size = new System.Drawing.Size(23, 23);
            this.Turuncu.TabIndex = 8;
            this.Turuncu.TabStop = false;
            this.Turuncu.Click += new System.EventHandler(this.Turuncu_Click);
            // 
            // Mavi
            // 
            this.Mavi.BackColor = System.Drawing.Color.Blue;
            this.Mavi.Location = new System.Drawing.Point(110, 45);
            this.Mavi.Name = "Mavi";
            this.Mavi.Size = new System.Drawing.Size(23, 23);
            this.Mavi.TabIndex = 7;
            this.Mavi.TabStop = false;
            this.Mavi.Click += new System.EventHandler(this.Mavi_Click);
            // 
            // Kirmizi
            // 
            this.Kirmizi.BackColor = System.Drawing.Color.Red;
            this.Kirmizi.Location = new System.Drawing.Point(29, 45);
            this.Kirmizi.Name = "Kirmizi";
            this.Kirmizi.Size = new System.Drawing.Size(23, 23);
            this.Kirmizi.TabIndex = 6;
            this.Kirmizi.TabStop = false;
            this.Kirmizi.Click += new System.EventHandler(this.Kirmizi_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(73, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Renk Seçimi";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Controls.Add(this.Silme);
            this.panel4.Controls.Add(this.Secme);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(785, 350);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(240, 182);
            this.panel4.TabIndex = 3;
            // 
            // Silme
            // 
            this.Silme.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Silme.BackgroundImage")));
            this.Silme.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Silme.FlatAppearance.BorderSize = 0;
            this.Silme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Silme.Location = new System.Drawing.Point(137, 66);
            this.Silme.Name = "Silme";
            this.Silme.Size = new System.Drawing.Size(68, 74);
            this.Silme.TabIndex = 8;
            this.Silme.UseVisualStyleBackColor = true;
            // 
            // Secme
            // 
            this.Secme.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Secme.BackgroundImage")));
            this.Secme.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Secme.FlatAppearance.BorderSize = 0;
            this.Secme.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Secme.Location = new System.Drawing.Point(18, 66);
            this.Secme.Name = "Secme";
            this.Secme.Size = new System.Drawing.Size(68, 74);
            this.Secme.TabIndex = 7;
            this.Secme.UseVisualStyleBackColor = true;
            this.Secme.Click += new System.EventHandler(this.Secme_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Seçme İşlemi";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.Kaydet);
            this.panel5.Controls.Add(this.Dosya_Cagırma);
            this.panel5.Location = new System.Drawing.Point(785, 533);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(240, 197);
            this.panel5.TabIndex = 4;
            // 
            // Dosya_Cagırma
            // 
            this.Dosya_Cagırma.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dosya_Cagırma.BackgroundImage")));
            this.Dosya_Cagırma.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Dosya_Cagırma.FlatAppearance.BorderSize = 0;
            this.Dosya_Cagırma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dosya_Cagırma.Location = new System.Drawing.Point(29, 62);
            this.Dosya_Cagırma.Name = "Dosya_Cagırma";
            this.Dosya_Cagırma.Size = new System.Drawing.Size(79, 84);
            this.Dosya_Cagırma.TabIndex = 8;
            this.Dosya_Cagırma.UseVisualStyleBackColor = true;
            // 
            // Kaydet
            // 
            this.Kaydet.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Kaydet.BackgroundImage")));
            this.Kaydet.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Kaydet.FlatAppearance.BorderSize = 0;
            this.Kaydet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Kaydet.Location = new System.Drawing.Point(144, 67);
            this.Kaydet.Name = "Kaydet";
            this.Kaydet.Size = new System.Drawing.Size(68, 74);
            this.Kaydet.TabIndex = 9;
            this.Kaydet.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(73, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Dosya İşlemi";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1025, 731);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Gri)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Pembe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Beyaz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Siyah)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Yesil)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Turuncu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mavi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Kirmizi)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Altigen;
        private System.Windows.Forms.Button Daire;
        private System.Windows.Forms.Button Ucgen;
        private System.Windows.Forms.Button Kare;
        private System.Windows.Forms.PictureBox Gri;
        private System.Windows.Forms.PictureBox Pembe;
        private System.Windows.Forms.PictureBox Beyaz;
        private System.Windows.Forms.PictureBox Mor;
        private System.Windows.Forms.PictureBox Siyah;
        private System.Windows.Forms.PictureBox Yesil;
        private System.Windows.Forms.PictureBox Turuncu;
        private System.Windows.Forms.PictureBox Mavi;
        private System.Windows.Forms.PictureBox Kirmizi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Silme;
        private System.Windows.Forms.Button Secme;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Kaydet;
        private System.Windows.Forms.Button Dosya_Cagırma;
    }
}

