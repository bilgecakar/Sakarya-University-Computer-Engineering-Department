﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paint
{
    class Kare:Tum_Sekiller
    {
        public int genislik;

        public void kare()
        {
            genislik = 0;
        }

        public override void Bitis(int bx, int by)
        {
            genislik = by - Y;

        }

        public override void Ciz(Graphics CizimAlani, Color renk)
        {
            
            SolidBrush firca = new SolidBrush(renk);
            CizimAlani.FillRectangle(firca, X, Y, genislik, genislik);
            firca.Dispose();
         

        }
    }
}
