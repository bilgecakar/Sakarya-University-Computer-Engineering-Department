﻿/****************************************************************************
**					         SAKARYA ÜNİVERSİTESİ
**			       BİLGİSAYAR VE BİLİŞİM BİLİMLERİ FAKÜLTESİ
**				        BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
**				       NESNEYE DAYALI PROGRAMLAMA DERSİ
**                              
**				öDEV NUMARASI: 1
**				ÖĞRENCİ ADI:BİLGE ÇAKAR
**				ÖĞRENCİ NUMARASI:G161210033
**				DERS GRUBU:D
****************************************************************************/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV; //EmguCv kütüphanelerini ekledim.
using Emgu.CV.UI;
using Emgu.Util;
using Emgu.CV.Structure;


namespace WindowsFormsApp12
{
    public partial class Form1 : Form
    {
      
        Image<Bgr, byte> RenkliImage; //Image tanımladım.Bu sayede diğer fonksiyonlar, dosyadan seçtiğim jpg üzerinden çalışacak.

        public Form1()
        {
            InitializeComponent();
        }

        
        public static Mat HistogramGetir(Image<Gray, byte> gri) //Histogram fonksiyonu.
        {
            DenseHistogram hist = new DenseHistogram(256, new RangeF(0, 256));
            hist.Calculate(new Image<Gray, Byte>[] { gri }, false, null);
            Mat m = new Mat();
            hist.CopyTo(m);
            return m;
        }

        public static Image<Gray, byte> BinaryGetir(Image<Gray, byte> gri)//Binary fonksiyonu.
        {
            int threshold = 70;
            Image<Gray, byte> binary = gri.ThresholdBinary(new Gray(threshold), new Gray(255));
            return binary;
        }
       
            private void button1_Click(object sender, EventArgs e) //Dosyadan jpg dosyası seçme.
        {
            //OpenFileDiaolog ile dosyayı açtım ve jpg türü dosyaları seçip ImageBox1'ta gösterecek.
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Open Image";
            dlg.Filter = "jpg files (*.jpg)|*.jpg";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                RenkliImage = new Image<Bgr,byte>(dlg.FileName);
                imageBox1.Image = RenkliImage;
            }
            dlg.Dispose();


        }

        private void button2_Click(object sender, EventArgs e) //Resmi griye çevirme.
        {
            
            if(RenkliImage == null) //Resim seçilmediği taktirde ekrana yazdıracak.
            {
                MessageBox.Show("Lutfen resim seciniz.");
                return;

            }

            //Renkli resmi gri resme dönüştürecek.
            Image<Gray, byte> GriImage = new Image<Gray, byte>(RenkliImage.Width, RenkliImage.Height, new Gray(0));
            GriImage = RenkliImage.Convert<Gray, byte>(); 
            imageBox2.Image = GriImage; //Gri resmi Imagebox2'da gösterecek.
            
        }

        private void button3_Click(object sender, EventArgs e) //Histogramı gösterme.
        {

            if (RenkliImage == null) //Resim seçilmediği taktirde ekrana yazdıracak.
            {
                MessageBox.Show("Lutfen resim seciniz.");
                return;

            }

            //Gri resmin histogramını HistogramBox1'da gösterecek.
            Image<Gray, byte> GriImage = new Image<Gray, byte>(RenkliImage.Width, RenkliImage.Height, new Gray(0));
            GriImage = RenkliImage.Convert<Gray, byte>();
            Mat m = HistogramGetir(GriImage);
            histogramBox1.ClearHistogram();
            histogramBox1.AddHistogram("Gri Histogram", Color.Gray, m, 256, new float[] { 0.0f, 256.0f });
            histogramBox1.Refresh();
        }

        private void button4_Click(object sender, EventArgs e) //Binary image dönüştürme.
        {

            if (RenkliImage == null) //Resim seçilmediği taktirde ekrana yazdıracak.
            {
                MessageBox.Show("Lutfen resim seciniz.");
                return;

            }
            //Gri resmi binary'e çevirecek ve ImageBox3'te gösterecek.
            Image<Gray, byte> GriImage = new Image<Gray, byte>(RenkliImage.Width, RenkliImage.Height, new Gray(0));
            GriImage = RenkliImage.Convert<Gray, byte>();
            imageBox3.Image = BinaryGetir(GriImage);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }
    }
}
