﻿namespace WindowsFormsApp8
{
    internal class kisi//Verileri tanımlamak için class oluşturdum.
    {
        public string Soyad { get; set; }
        public string No { get; set; }
        public string ad { get; set; }
        public string renk { get; set; }
        public string str1;
        public string str2;
        public string str3;
  
    }

    public class comboboxItem
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}