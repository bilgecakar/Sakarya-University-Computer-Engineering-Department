# SQLite Example

**This example has moved to [examples/with-sqlite](https://github.com/expo/examples/tree/master/with-sqlite)**
