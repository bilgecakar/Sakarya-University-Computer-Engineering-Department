#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fields.h"
#include "jval.h"
int main()
{
     Jval a;
     int b;

     a.i = 5;

     b = jval_i(a); // a.i

     printf("b = %d\n", b);



}
