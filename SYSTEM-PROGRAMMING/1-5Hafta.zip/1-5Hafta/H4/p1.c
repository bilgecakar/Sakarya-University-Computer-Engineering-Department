#include "fields.h"

void main()
{
     IS fr;
     int nf, i;

     fr = new_inputstruct("t1.txt");
     nf = get_line(fr);
     while(nf > 0){
	  for(i = 0; i < nf; i++){
	       printf("%s\n",fr->fields[i]);
	  }
	  printf("----------------\n");
	  nf = get_line(fr);
     }

     jettison_inputstruct(fr);
}
