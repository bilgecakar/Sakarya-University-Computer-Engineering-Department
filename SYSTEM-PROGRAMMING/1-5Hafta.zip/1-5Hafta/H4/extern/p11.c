#include<stdio.h>

extern int a;

void foo()
{
     int c;
     a = 5;
     printf("Burası foo\n");
     printf("2. dosyada  a = %d\n", a);

}
