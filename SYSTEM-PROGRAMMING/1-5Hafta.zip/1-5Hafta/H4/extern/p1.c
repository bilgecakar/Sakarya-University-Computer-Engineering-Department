#include<stdio.h>

//extern void foo();
 
int a;

int main()
{
     a = 5;

     printf("1. dosyada  a = %d\n", a);

     foo();

     return 0; 
}
