#include<stdio.h>
#include <stdlib.h>

int a; // Global değişken

void main()
{
     int b; // Lokal değişken
     int bb; // Lokal değişken
     int *ap;
     int *bp;
     int *bbp;
     int *cp;
     int *ccp;

     ap = &a;
     bp = &b;
     bbp = &bb;
     cp = (int *) malloc(sizeof(int));
     ccp = (int *) malloc(sizeof(int));

     printf("a nın adresi 0x%x\n", (unsigned int) ap);
     printf("b nın adresi 0x%x\n", (unsigned int) bp);
     printf("bb nın adresi 0x%x\n", (unsigned int) bbp);
     printf("c nın adresi 0x%x\n", (unsigned int) cp);
     printf("cc nın adresi 0x%x\n", (unsigned int) ccp);
}
